import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:petvac/app/models/base_model.dart';

class Pets extends BaseModel {
  static const String COLLECTION_NAME = 'Pets';
  static const String NOME = "nome",
      DATA_NASCIMENTO = "data_nascimento",
      PETTIPOS_ID = "pettipos_id",
      SEXO = "sexo";
  String _documentId;
  String nome, petTiposId, sexo;
  DateTime dataNascimento;

  Pets();

  @override
  String documentId() {
    return this._documentId;
  }

  @override
  Pets.fromMap(DocumentSnapshot document) {
    this._documentId = document.documentID.toString();

    this.nome = document.data[Pets.NOME];
    Timestamp ts = document.data[Pets.DATA_NASCIMENTO];
    this.dataNascimento =
        DateTime.fromMillisecondsSinceEpoch(ts.millisecondsSinceEpoch);
    this.petTiposId = document.data[Pets.PETTIPOS_ID];
    this.sexo = document.data[Pets.SEXO];
  }

  @override
  toMap() {
    var map = new Map<String, dynamic>();
    map[Pets.NOME] = this.nome;
    map[Pets.DATA_NASCIMENTO] = this.dataNascimento;
    map[Pets.PETTIPOS_ID] = this.petTiposId;
    map[Pets.SEXO] = this.sexo;

    return map;
  }
}
