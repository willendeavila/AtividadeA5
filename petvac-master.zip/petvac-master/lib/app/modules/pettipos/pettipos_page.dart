import 'package:flutter/material.dart';
import 'package:petvac/app/models/pettipos_model.dart';
import 'package:petvac/app/modules/pettipos/pettipos_bloc.dart';
import 'package:petvac/app/utils/main_drawer.dart';
import 'package:rxdart/rxdart.dart';

import 'pettipos_edit_page.dart';

class PetTiposPage extends StatefulWidget {
  final String title;
  static const String route = '/petTipos';

  const PetTiposPage({Key key, this.title = "Tipos de Pet"}) : super(key: key);

  @override
  _PetTiposPageState createState() => _PetTiposPageState();
}

class _PetTiposPageState extends State<PetTiposPage> {
  var _bloc = PetTiposBloc();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: MainDrawer(),
      appBar: AppBar(
        title: Text(widget.title),
      ),
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.add),
        onPressed: () {
          var _petTipos = PetTipos()..nome = "";

          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => PetTiposEditPage(_petTipos),
            ),
          );
        },
      ),
      body: Container(
        child: StreamBuilder<List<PetTipos>>(
          stream: _bloc.getPetTipos,
          builder: (context, snapshot) {
            if (!snapshot.hasData) return CircularProgressIndicator();

            return Container(
              child: ListView(
                children: snapshot.data.map(
                  (_petTipos) {
                    return Dismissible(
                      key: Key(_petTipos.documentId()),
                      onDismissed: (direction) {
                        _bloc.delete(_petTipos.documentId());
                      },
                      child: ListTile(
                        title: Text(_petTipos.nome),
                        trailing: Icon(Icons.keyboard_arrow_right),
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => PetTiposEditPage(_petTipos),
                            ),
                          );
                        },
                      ),
                    );
                  },
                ).toList(),
              ),
            );
          },
        ),
      ),
    );
  }
}
