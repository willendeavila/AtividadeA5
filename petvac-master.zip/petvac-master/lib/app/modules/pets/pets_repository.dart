import 'package:bloc_pattern/bloc_pattern.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:dio/dio.dart';
import 'package:petvac/app/models/pets_model.dart';
import 'package:rxdart/rxdart.dart';

class PetsRepository extends Disposable {
  CollectionReference _collection =
      Firestore.instance.collection(Pets.COLLECTION_NAME);

  void add(Pets _pets) => _collection.add(_pets.toMap());

  void update(String _documentId, Pets _pets) =>
      _collection.document(_documentId).updateData(_pets.toMap());

  void delete(String _documentId) => _collection.document(_documentId).delete();

  Observable<List<Pets>> get getAll =>
      Observable(_collection.snapshots().map((query) => query.documents
          .map<Pets>((document) => Pets.fromMap(document))
          .toList()));

  Future<Pets> getById(String _documentId) async {
    DocumentSnapshot _pets = await _collection.document(_documentId).get();

    return Pets.fromMap(_pets);
  }

  Future fetchPost(Dio client) async {
    final response =
        await client.get('https://jsonplaceholder.typicode.com/posts/1');
    return response.data;
  }

  //dispose will be called automatically
  @override
  void dispose() {}
}
