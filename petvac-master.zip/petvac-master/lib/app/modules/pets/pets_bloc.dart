import 'package:bloc_pattern/bloc_pattern.dart';
import 'package:petvac/app/models/pets_model.dart';
import 'package:petvac/app/modules/pets/pets_repository.dart';
import 'package:rxdart/rxdart.dart';

import '../../app_module.dart';

class PetsBloc extends BlocBase {
  var _repository = AppModule.to.getDependency<PetsRepository>();
  String _documentId;
  String _nome, _petTiposId, _sexo;
  DateTime _dataNascimento;

  PetsBloc() {
    _nomeController.listen((value) => _nome = value);
    _petTiposIdController.listen((value) => _petTiposId = value);
    _sexoController.listen((value) => _sexo = value);
    _dataNascimentoController.listen((value) => _dataNascimento = value);
  }

  // Nome
  var _nomeController = BehaviorSubject<String>();
  Stream<String> get outNome => _nomeController.stream;
  void setNome(String value) => _nomeController.sink.add(value);

  // PetTiposId
  var _petTiposIdController = BehaviorSubject<String>();
  Stream<String> get outPetTiposId => _petTiposIdController.stream;
  String get outPetTiposIdValue => _petTiposIdController.stream.value;
  void setPetTiposId(String value) => _petTiposIdController.sink.add(value);

  // Sexo
  var _sexoController = BehaviorSubject<String>();
  Stream<String> get outSexo => _sexoController.stream;
  String get outSexoValue => _sexoController.stream.value;
  void setSexo(String value) => _sexoController.sink.add(value);

  // DataNascimento
  var _dataNascimentoController = BehaviorSubject<DateTime>();
  Stream<DateTime> get outDataNascimento => _dataNascimentoController.stream;
  void setDataNascimento(DateTime value) =>
      _dataNascimentoController.sink.add(value);

  Observable<List<Pets>> get getPets => _repository.getAll;

  void delete(String _documentId) => _repository.delete(_documentId);

  void setPets(Pets pets) {
    _documentId = pets.documentId();
    setNome(pets.nome);
    setDataNascimento(pets.dataNascimento);
    setPetTiposId(pets.petTiposId);
    setSexo(pets.sexo);
  }

  bool insertOrUpdate() {
    var _pets = Pets()
      ..nome = _nome
      ..petTiposId = _petTiposId
      ..sexo = _sexo
      ..dataNascimento = _dataNascimento;

    if (_documentId?.isEmpty ?? true) {
      _repository.add(_pets);
    } else {
      _repository.update(_documentId, _pets);
    }

    return true;
  }

  @override
  void dispose() {
    super.dispose();
  }
}
