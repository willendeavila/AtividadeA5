import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:petvac/app/models/pets_model.dart';
import 'package:petvac/app/utils/main_drawer.dart';

import 'pets_bloc.dart';
import 'pets_edit_page.dart';

class PetsPage extends StatefulWidget {
  final String title;
  static const String route = '/pets';

  const PetsPage({Key key, this.title = "Pets"}) : super(key: key);

  @override
  _PetsPageState createState() => _PetsPageState();
}

class _PetsPageState extends State<PetsPage> {
  var _bloc = PetsBloc();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: MainDrawer(),
      appBar: AppBar(
        title: Text(widget.title),
      ),
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.add),
        onPressed: () {
          var _pets = Pets()
            ..nome = ""
            ..petTiposId = ""
            ..sexo = ""
            ..dataNascimento = DateTime.now();

          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => PetsEditPage(_pets),
            ),
          );
        },
      ),
      body: Container(
        child: StreamBuilder<List<Pets>>(
          stream: _bloc.getPets,
          builder: (context, snapshot) {
            if (!snapshot.hasData) return CircularProgressIndicator();

            return Container(
              child: ListView(
                children: snapshot.data.map(
                  (_pets) {
                    return Dismissible(
                      key: Key(_pets.documentId()),
                      onDismissed: (direction) {
                        _bloc.delete(_pets.documentId());
                      },
                      child: ListTile(
                        title: Text(_pets.nome),
                        subtitle: Text(new DateFormat("dd-MM-yyyy")
                            .format(_pets.dataNascimento)),
                        trailing: Icon(Icons.keyboard_arrow_right),
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => PetsEditPage(_pets),
                            ),
                          );
                        },
                      ),
                    );
                  },
                ).toList(),
              ),
            );
          },
        ),
      ),
    );
  }
}
