import 'package:petvac/app/modules/home/home_page.dart';
import 'package:petvac/app/modules/logon/logon_page.dart';
import 'package:petvac/app/modules/pets/pets_page.dart';
import 'package:petvac/app/modules/pettipos/pettipos_page.dart';

class Routes {
  static const String home = HomePage.route;
  static const String petTipos = PetTiposPage.route;
  static const String pets = PetsPage.route;
  static const String logon = LogonPage.route;
}
