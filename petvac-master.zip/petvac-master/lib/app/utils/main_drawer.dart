import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import 'routes.dart';

class MainDrawer extends StatelessWidget {
  const MainDrawer({
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        children: <Widget>[
          DrawerHeader(
            decoration: BoxDecoration(
                image: DecorationImage(
                    image: AssetImage('assets/images/programmer_dog.png')),
                color: Colors.green),
            child: Stack(
              children: <Widget>[
                Positioned(child: Text("PetVac Menu")),
                Positioned(
                  bottom: 0.0,
                  child: OutlineButton(
                    shape: StadiumBorder(),
                    textColor: Colors.blue,
                    child: Text('Sair'),
                    borderSide: BorderSide(
                        color: Colors.blue, style: BorderStyle.solid, width: 1),
                    onPressed: () {
                      FirebaseAuth.instance.signOut().then((valor) {
                        Navigator.pushReplacementNamed(context, Routes.logon);
                      });
                    },
                  ),
                )
              ],
            ),
          ),
          _addDrawerItem(
            Icons.home,
            'Home',
            () => Navigator.pushReplacementNamed(context, Routes.home),
          ),
          _addDrawerItem(
            Icons.mouse,
            'Tipos de Pet',
            () => Navigator.pushReplacementNamed(context, Routes.petTipos),
          ),
          _addDrawerItem(
            Icons.mood,
            'Pets',
            () => Navigator.pushReplacementNamed(context, Routes.pets),
          ),
        ],
      ),
    );
  }
}

Widget _addDrawerItem(_icon, _text, _onTap) {
  return ListTile(
    title: Row(
      children: <Widget>[
        Icon(_icon),
        Padding(
          padding: EdgeInsets.only(left: 8),
          child: Text(_text),
        )
      ],
    ),
    onTap: _onTap,
  );
}
