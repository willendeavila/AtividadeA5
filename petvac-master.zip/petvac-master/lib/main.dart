import 'package:flutter/material.dart';
import 'package:petvac/app/app_module.dart';

void main() => runApp(AppModule());
